const BOT_TOKEN = '8685322461:AAEKsirJ_cZNeycRv42B4lv5XsWcuQljQfU';
const CHAT_ID = '8685322461';

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);

    const message =
      '🌾 НОВА ЗАЯВКА НА ПАЙ\n\n' +
      '📍 Населений пункт: ' + (data.settlement || '—') + '\n' +
      '📐 Площа: ' + (data.area || '—') + '\n' +
      '📋 Кадастровий номер: ' + (data.cadastral || '—') + '\n' +
      '📝 Оренда: ' + (data.lease || '—') + '\n' +
      '📅 До: ' + (data.leaseYear || '—') + '\n' +
      '📞 Телефон: ' + (data.phone || '—');

    const url = 'https://api.telegram.org/bot' + BOT_TOKEN + '/sendMessage';

    UrlFetchApp.fetch(url, {
      method: 'post',
      contentType: 'application/json',
      payload: JSON.stringify({
        chat_id: CHAT_ID,
        text: message
      }),
      muteHttpExceptions: true
    });

    return ContentService
      .createTextOutput(JSON.stringify({success: true}))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (error) {
    return ContentService
      .createTextOutput(JSON.stringify({
        success: false,
        error: error.toString()
      }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
